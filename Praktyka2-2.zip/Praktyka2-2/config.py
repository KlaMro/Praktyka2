import os
"""
Central configuration file for the application.
"""

# --- Database ---
DATABASE_PATH = 'leads.db'

# --- Financials ---
COMMISSION_RATE = 0.15
ROI_MULTIPLIER = 2.5
TIME_FRAME_MONTHS = 3

# --- PDF Generation ---
FPDF_FONT_PATH = 'font/'
SAFE_WIDTH = 190

# --- Email (Gmail Example) ---
# IMPORTANT: For Gmail, you MUST use an "App Password", not your regular password.
# See instructions here: https://support.google.com/accounts/answer/185833
SMTP_SERVER = 'smtp.gmail.com'
SMTP_PORT = 587
FROM_EMAIL = "klaudiamroz05@gmail.com"
SMTP_USER = "klaudiamroz05@gmail.com"
SMTP_PASSWORD = "rkdmkznfffzunliu"

EMAIL_SUBJECT = "Twoja spersonalizowana wycena - gotowa do pobrania!"
EMAIL_BODY = f"""Dzień dobry,\n\nDziękujemy za skorzystanie z naszego kalkulatora.\n\nW załączniku przesyłamy spersonalizowany raport z wyceną i wstępnym harmonogramem działań dla Twojej firmy.\n\nNasz specjalista skontaktuje się z Tobą w ciągu 24 godzin, aby omówić szczegóły.\n\nPozdrawiamy,\nZespół Twojej Agencji\n"""

# --- Competitor Analysis ---
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'

# --- Admin ---
ADMIN_USERNAME = "admin"
# The hashed password for "admin"
ADMIN_PASSWORD_HASH = 'pbkdf2:sha256:600000$NXcC5HLNMQRR9PVm$1e89af58e8c6a8e9afe5efb96a4b93a2666db959b66227632265509c20323f13'

SECRET_KEY = os.urandom(24).hex()

