
import sqlite3
import threading
from flask import Flask, render_template, request, jsonify, session, redirect, url_for, flash, g, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta

import config
from tasks import create_pdf_report_and_send_email

app = Flask(__name__)
app.config['SECRET_KEY'] = config.SECRET_KEY

# --- START: CACHE BUSTING CONFIG ---
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0
# --- END: CACHE BUSTING CONFIG ---

def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(config.DATABASE_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(exception):
    db = g.pop('db', None)
    if db is not None:
        db.close()

def init_db():
    with app.app_context():
        db = get_db()
        with app.open_resource('schema.sql', mode='r') as f:
            db.cursor().executescript(f.read())
        db.commit()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/calculate_budget', methods=['POST'])
def calculate_budget():
    budget = float(request.json['budget'])
    commission = budget * config.COMMISSION_RATE
    roi = budget * config.ROI_MULTIPLIER
    return jsonify({
        'commission': commission,
        'roi': roi
    })

@app.route('/select_goal', methods=['POST'])
def select_goal():
    goal = request.json['goal']
    packages = {
        'more_calls': 'SEO + Google Ads',
        'more_sales': 'Google Ads + Social Media Marketing',
        'new_brand': 'Social Media Marketing + Content Marketing',
        'seo_national': 'SEO (Ogólnokrajowe) + Content Marketing'
    }
    package = packages.get(goal, 'Nie wybrano pakietu')
    return jsonify({
        'package': package
    })

@app.route('/generate_report', methods=['POST'])
def generate_report():
    data = request.json
    email = data['email']
    budget = float(data['budget'])
    goal = data['goal']
    competitors = data.get('competitors', [])
    package = select_goal().get_json()['package']

    report_data = {
        'email': email,
        'budget': budget,
        'goal': goal,
        'competitors': competitors
    }

    thread = threading.Thread(target=create_pdf_report_and_send_email, args=(app, report_data, package))
    thread.start()

    return jsonify({
        'message': f"Dziękujemy! Twój raport jest w trakcie przygotowania i zostanie wysłany na adres {email} w ciągu kilku minut."
    })

# --- Admin Panel ---

@app.route('/admin/login', methods=['GET', 'POST'])
def login():
    if 'logged_in' in session:
        return redirect(url_for('admin_panel'))

    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        if username == config.ADMIN_USERNAME and check_password_hash(config.ADMIN_PASSWORD_HASH, password):
            session['logged_in'] = True
            flash('Zalogowano pomyślnie!', 'success')
            return redirect(url_for('admin_panel'))
        else:
            flash('Nieprawidłowe dane logowania.', 'danger')
            
    return render_template('login.html')

@app.route('/admin/logout')
def logout():
    session.pop('logged_in', None)
    flash('Wylogowano pomyślnie.', 'success')
    return redirect(url_for('login'))

@app.route('/admin')
def admin_panel():
    if 'logged_in' not in session:
        return redirect(url_for('login'))
    
    db = get_db()
    
    # --- Analytics Data --- #

    # 1. Leads over time (last 7 days)
    today = datetime.utcnow().date()
    date_labels = [(today - timedelta(days=i)).strftime('%Y-%m-%d') for i in range(6, -1, -1)]
    leads_count_by_date = {label: 0 for label in date_labels}
    
    seven_days_ago = today - timedelta(days=7)
    leads_last_7_days = db.execute(
        'SELECT DATE(timestamp) as lead_date FROM leads WHERE DATE(timestamp) >= ?', (seven_days_ago,)
    ).fetchall()
    
    for lead in leads_last_7_days:
        if lead['lead_date'] in leads_count_by_date:
            leads_count_by_date[lead['lead_date']] += 1
    
    leads_over_time_data = {
        'labels': list(leads_count_by_date.keys()),
        'data': list(leads_count_by_date.values())
    }

    # 2. Goal distribution (pie chart)
    goal_dist_rows = db.execute('SELECT goal, COUNT(id) as count FROM leads GROUP BY goal').fetchall()
    goal_distribution_data = {
        'labels': [row['goal'] for row in goal_dist_rows],
        'data': [row['count'] for row in goal_dist_rows]
    }

    # --- Basic Stats & Lead List --- #
    
    leads = db.execute('SELECT * FROM leads ORDER BY timestamp DESC').fetchall()
    total_leads = len(leads)
    avg_budget_row = db.execute('SELECT AVG(budget) FROM leads').fetchone()
    avg_budget = avg_budget_row[0] if avg_budget_row else 0
    
    return render_template(
        'admin.html', 
        leads=leads, 
        total_leads=total_leads, 
        avg_budget=avg_budget,
        leads_over_time=leads_over_time_data,
        goal_distribution=goal_distribution_data
    )

@app.route('/admin/download_report/<filename>')
def download_report(filename):
    if 'logged_in' not in session:
        return redirect(url_for('login'))
    
    if '..' in filename or filename.startswith('/'):
        return "Błąd: Nieprawidłowa nazwa pliku.", 400
        
    return send_from_directory('.', filename, as_attachment=True)


if __name__ == '__main__':
    init_db() # Inicjalizacja bazy danych
    app.run(debug=True)
