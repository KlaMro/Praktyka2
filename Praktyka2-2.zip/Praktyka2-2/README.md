# Praktyka2
