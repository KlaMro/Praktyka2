
from werkzeug.security import generate_password_hash
import getpass

def main():
    """Generuje hash hasła dla panelu administratora."""
    print("--- Generator Hasha Hasła Administratora ---")
    
    try:
        new_password = getpass.getpass("Wprowadź nowe hasło: ")
        confirm_password = getpass.getpass("Potwierdź nowe hasło: ")

        if not new_password or not confirm_password:
            print("\nBŁĄD: Hasło nie może być puste.")
            return

        if new_password != confirm_password:
            print("\nBŁĄD: Wprowadzone hasła nie są identyczne. Spróbuj ponownie.")
            return
        
        # Używamy tej samej metody hashowania co w aplikacji, aby zapewnić spójność
        hashed_password = generate_password_hash(new_password, method='pbkdf2:sha256:600000')

        print("\n\nGotowe! Oto Twój nowy hash hasła:")
        print("="*70)
        print(hashed_password)
        print("="*70)
        print("\nKROKI:")
        print("1. Skopiuj całą powyższą linię z hashem (zaczynającą się od 'pbkdf2:sha256:...').")
        print("2. Otwórz plik config.py.")
        print("3. Znajdź linię ADMIN_PASSWORD_HASH = 'stary_hash_tutaj' i zamień stary hash na ten nowy.")

    except Exception as e:
        print(f"\nWystąpił nieoczekiwany błąd: {e}")

if __name__ == '__main__':
    main()
