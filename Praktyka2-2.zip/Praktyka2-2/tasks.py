
import smtplib
import sqlite3
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from fpdf import FPDF
from datetime import datetime
import requests
from bs4 import BeautifulSoup

import config

# --- PDF Generation ---

class PDF(FPDF):
    def header(self):
        self.add_font('DejaVu', '', 'font/DejaVuSans.ttf', uni=True)
        self.set_font('DejaVu', '', 12)
        self.cell(0, 10, 'Spersonalizowana Wycena Marketingowa', 0, 1, 'C')
        self.ln(10)

    def footer(self):
        self.set_y(-15)
        self.add_font('DejaVu', '', 'font/DejaVuSans.ttf', uni=True)
        self.set_font('DejaVu', '', 8)
        self.cell(0, 10, f'Strona {self.page_no()}', 0, 0, 'C')

    def chapter_title(self, title):
        self.add_font('DejaVu', '', 'font/DejaVuSans-Bold.ttf', uni=True)
        self.set_font('DejaVu', '', 16)
        self.cell(0, 10, title, 0, 1, 'L')
        self.ln(5)

    def chapter_body(self, body):
        self.add_font('DejaVu', '', 'font/DejaVuSans.ttf', uni=True)
        self.set_font('DejaVu', '', 12)
        self.multi_cell(0, 10, body)
        self.ln()

    def add_summary_table(self, data, package):
        self.add_font('DejaVu', '', 'font/DejaVuSans-Bold.ttf', uni=True)
        self.set_font('DejaVu', '', 12)
        self.cell(0, 10, "Podsumowanie Twojej Wyceny", 0, 1, 'L')
        self.ln(5)

        self.add_font('DejaVu', '', 'font/DejaVuSans.ttf', uni=True)
        self.set_font('DejaVu', '', 11)

        line_height = self.font_size * 2
        col_width = self.w / 2.2 # Szerokość kolumn

        table_data = [
            ("Twój cel biznesowy:", data['goal']),
            ("Rekomendowany pakiet:", package),
            ("Miesięczny budżet:", f"{data['budget']} zł"),
            ("Nasza prowizja (15%):", f"{data['budget'] * config.COMMISSION_RATE:.2f} zł"),
            ("Szacowany zwrot (ROI) w 3 m-ce:", f"{data['budget'] * config.ROI_MULTIPLIER:.2f} zł"),
        ]

        for row in table_data:
            self.cell(col_width, line_height, row[0], border=1)
            self.cell(col_width, line_height, row[1], border=1)
            self.ln(line_height)
        self.ln(10)

    def add_competitor_analysis_section(self, competitor_data):
        if not competitor_data:
            return

        self.add_page()
        self.chapter_title("Analiza Konkurencji")

        self.add_font('DejaVu', '', 'font/DejaVuSans-Bold.ttf', uni=True)
        self.set_font('DejaVu', '', 10)
        
        # Ustawienie szerokości kolumn
        col_widths = [self.w * 0.3, self.w * 0.3, self.w * 0.3]
        self.set_fill_color(230, 230, 230)

        # Nagłówki tabeli
        self.cell(col_widths[0], 10, "Adres URL", 1, 0, 'C', 1)
        self.cell(col_widths[1], 10, "Tytuł Strony", 1, 0, 'C', 1)
        self.multi_cell(col_widths[2], 10, "Meta Opis", 1, 'C', 1)

        self.add_font('DejaVu', '', 'font/DejaVuSans.ttf', uni=True)
        self.set_font('DejaVu', '', 9)

        for item in competitor_data:
            self.ln(0.5) # Mały odstęp
            x = self.get_x()
            y = self.get_y()

            # Użycie multi_cell dla wszystkich kolumn, aby zawijać tekst
            self.multi_cell(col_widths[0], 10, item['url'], border=1, align='L')
            self.set_xy(x + col_widths[0], y)
            self.multi_cell(col_widths[1], 10, item['title'], border=1, align='L')
            self.set_xy(x + col_widths[0] + col_widths[1], y)
            self.multi_cell(col_widths[2], 10, item['description'], border=1, align='L')

# --- Competitor Analysis ---

def analyze_competitors(urls):
    """Analizuje podane adresy URL w poszukiwaniu tytułu i meta opisu."""
    results = []
    headers = {'User-Agent': config.USER_AGENT}

    for url in urls:
        try:
            # Dodanie http, jeśli brakuje
            if not url.startswith(('http://', 'https://')):
                url_to_fetch = 'http://' + url
            else:
                url_to_fetch = url

            response = requests.get(url_to_fetch, headers=headers, timeout=10)
            response.raise_for_status() # Rzuć błąd dla złych odpowiedzi (4xx lub 5xx)
            soup = BeautifulSoup(response.content, 'html.parser')

            title = soup.find('title').get_text(strip=True) if soup.find('title') else "Nie znaleziono tytułu"
            description_tag = soup.find('meta', attrs={'name': 'description'})
            description = description_tag['content'].strip() if description_tag else "Nie znaleziono opisu"

            results.append({'url': url, 'title': title, 'description': description})
        except requests.RequestException as e:
            results.append({'url': url, 'title': "Błąd połączenia", 'description': str(e)})
        except Exception as e:
            results.append({'url': url, 'title': "Nieoczekiwany błąd", 'description': str(e)})
            
    return results

# --- Main Task ---

def create_pdf_report_and_send_email(app, data, package):
    with app.app_context():
        try:
            # 1. Zapisz wstępne dane leada do bazy danych
            conn = sqlite3.connect(config.DATABASE_PATH)
            c = conn.cursor()
            c.execute(
                "INSERT INTO leads (email, budget, goal, package) VALUES (?, ?, ?, ?)",
                (data['email'], data['budget'], data['goal'], package)
            )
            lead_id = c.lastrowid # Pobierz ID nowo wstawionego leada
            conn.commit()

            # 2. Analiza konkurencji
            competitor_data = []
            if data.get('competitors'):
                competitor_data = analyze_competitors(data['competitors'])

            # 3. Wygeneruj raport PDF
            pdf = PDF()
            pdf.add_page()
            pdf.add_summary_table(data, package)
            pdf.add_competitor_analysis_section(competitor_data)

            pdf.chapter_title("Nasza Strategia")
            pdf.chapter_body(
                "Naszym celem jest maksymalizacja Twojego zwrotu z inwestycji poprzez precyzyjne dotarcie do grupy docelowej. "
                "Wykorzystamy do tego kombinację wybranych przez Ciebie usług, optymalizując kampanie w czasie rzeczywistym, "
                "aby zapewnić jak najlepsze wyniki."
            )
            
            safe_email = data['email'].replace('@', '_at_').replace('.', '_dot_')
            filename = f"report_{safe_email}_{datetime.now().strftime('%Y%m%d%H%M%S')}.pdf"
            pdf.output(filename)

            # 4. Zaktualizuj leada o nazwę pliku raportu
            c.execute("UPDATE leads SET report_filename = ? WHERE id = ?", (filename, lead_id))
            conn.commit()
            conn.close()

            # 5. Wyślij email z załącznikiem
            msg = MIMEMultipart()
            msg['From'] = config.FROM_EMAIL
            msg['To'] = data['email']
            msg['Subject'] = config.EMAIL_SUBJECT
            msg.attach(MIMEText(config.EMAIL_BODY, 'plain'))

            with open(filename, "rb") as attachment:
                part = MIMEBase('application', 'octet-stream')
                part.set_payload(attachment.read())
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', f"attachment; filename= {filename}")
            msg.attach(part)

            with smtplib.SMTP(config.SMTP_SERVER, config.SMTP_PORT) as server:
                server.starttls() # Włącz szyfrowanie
                server.login(config.SMTP_USER, config.SMTP_PASSWORD) # Zaloguj się na serwer
                server.send_message(msg)
                
            print(f"Raport dla {data['email']} został pomyślnie wygenerowany i wysłany.")

        except Exception as e:
            print(f"Wystąpił błąd podczas tworzenia raportu dla {data['email']}: {e}")
