DROP TABLE IF EXISTS leads;

CREATE TABLE leads (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL,
    budget REAL NOT NULL,
    goal TEXT NOT NULL,
    package TEXT NOT NULL,
    report_filename TEXT, -- Nowa kolumna na nazwę pliku z raportem
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
);
