
document.addEventListener('DOMContentLoaded', () => {
    // --- Element Selectors ---
    const budgetSlider = document.getElementById('budget');
    const budgetValue = document.getElementById('budgetValue');
    const commissionValue = document.getElementById('commissionValue');
    const roiValue = document.getElementById('roiValue');
    const packageResult = document.getElementById('packageResult');
    const emailForm = document.getElementById('email-form');
    const emailInput = document.getElementById('email-input');
    const companyNameInput = document.getElementById('company-name-input');
    const phoneNumberInput = document.getElementById('phone-number-input');
    const competitorsInput = document.getElementById('competitors-input');
    const reportStatus = document.getElementById('reportStatus');
    const quiz = document.getElementById('quiz');
    const emailSubmitButton = document.getElementById('email-submit');
    const submitSpinner = emailSubmitButton.querySelector('.spinner-border');

    let currentGoal = null;

    // --- Budget Calculator ---
    async function updateBudget() {
        const budget = budgetSlider.value;
        budgetValue.textContent = `${budget} PLN`;
        try {
            const response = await fetch('/calculate_budget', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ budget: budget })
            });
            const data = await response.json();
            commissionValue.textContent = `${data.commission.toFixed(2)} PLN`;
            roiValue.textContent = `${data.roi.toFixed(2)} PLN`;
        } catch (error) {
            console.error("Error calculating budget:", error);
            commissionValue.textContent = "Błąd";
            roiValue.textContent = "Błąd";
        }
    }

    // --- Goal Selection ---
    async function selectGoal(goal) {
        currentGoal = goal;
        packageResult.textContent = 'Analizowanie...';
        try {
            const response = await fetch('/select_goal', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ goal: goal })
            });
            const data = await response.json();
            packageResult.textContent = data.package;
        } catch (error) {
            console.error("Error selecting goal:", error);
            packageResult.textContent = "Błąd";
        }
    }

    // --- Quiz Logic (Rewritten for clarity) ---
    function handleQuiz(event) {
        const target = event.target;
        if (target.tagName !== 'BUTTON' || !target.closest('#quiz')) return;

        const questionDiv = target.closest('.quiz-question');
        if (!questionDiv) return;

        const answer = target.dataset.answer;
        const questionId = questionDiv.id;

        // Style active button
        questionDiv.querySelectorAll('button').forEach(btn => btn.classList.remove('active'));
        target.classList.add('active');

        // --- Logic for Question 1 ---
        if (questionId === 'question1') {
            const q2_visibility = document.getElementById('question2-visibility');
            const q2_leads = document.getElementById('question2-leads');

            // Reset sub-questions and result when Q1 changes
            q2_visibility.style.display = 'none';
            q2_leads.style.display = 'none';
            packageResult.textContent = '...';
            currentGoal = null;

            if (answer === 'visibility') {
                q2_visibility.style.display = 'block';
            } else if (answer === 'leads') {
                q2_leads.style.display = 'block';
            } else if (answer === 'brand') {
                selectGoal('new_brand');
            }
            return; // Stop processing here for Q1
        }

        // --- Logic for Question 2 ---
        if (questionId === 'question2-visibility' || questionId === 'question2-leads') {
            let goal = null;
            switch(answer) {
                case 'local':
                case 'services':
                    goal = 'more_calls';
                    break;
                case 'national':
                    goal = 'seo_national';
                    break;
                case 'ecommerce':
                    goal = 'more_sales';
                    break;
            }
            if (goal) {
                selectGoal(goal);
            }
        }
    }

    // --- Report Generation ---
    async function generateReport(event) {
        event.preventDefault();
        const email = emailInput.value;
        if (!email) {
            reportStatus.textContent = 'Proszę podać adres e-mail.';
            reportStatus.className = 'text-warning';
            return;
        }
        if (!currentGoal) {
            reportStatus.textContent = 'Proszę najpierw ukończyć quiz.';
            reportStatus.className = 'text-warning';
            return;
        }
        
        reportStatus.textContent = '';
        submitSpinner.style.display = 'inline-block';
        emailSubmitButton.disabled = true;

        try {
            const response = await fetch('/generate_report', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ 
                    email: email,
                    budget: budgetSlider.value,
                    goal: currentGoal,
                    company_name: companyNameInput.value,
                    phone_number: phoneNumberInput.value,
                    competitors: competitorsInput.value
                })
            });
            const data = await response.json();
            reportStatus.textContent = data.message;
            reportStatus.className = data.message.includes("Błąd") ? 'text-warning' : 'text-white';
            if (!data.message.includes("Błąd")) {
                emailForm.reset();
                quiz.querySelectorAll('.quiz-question button.active').forEach(btn => btn.classList.remove('active'));
                document.getElementById('question2-visibility').style.display = 'none';
                document.getElementById('question2-leads').style.display = 'none';
                packageResult.textContent = '...';
                currentGoal = null;
            }
        } catch (error) {
            console.error("Error generating report:", error);
            reportStatus.textContent = "Wystąpił nieoczekiwany błąd.";
            reportStatus.className = 'text-warning';
        } finally {
            submitSpinner.style.display = 'none';
            emailSubmitButton.disabled = false;
        }
    }

    // --- Initialization and Event Listeners ---
    budgetSlider.addEventListener('input', updateBudget);
    emailForm.addEventListener('submit', generateReport);
    quiz.addEventListener('click', handleQuiz);
    updateBudget(); // Initial calculation
});
