{ pkgs, ... }:
{
  # The Nix packages to make available in your workspace.
  packages = [ pkgs.python3 pkgs.pip pkgs.corefonts ];

  # The VS Code extensions to make available in your workspace.
  idx.extensions = [ "ms-python.python" ];

  # The commands to run when your workspace is created.
  idx.workspace.onCreate.pip-install = "pip install -r requirements.txt";

  # The commands to run when your workspace is started.
  idx.workspace.onStart.start-app = "python app.py";

  # The services to expose in your workspace.
  idx.previews = {
    enable = true;
    previews = {
      web = {
        command = ["python" "app.py" "--port" "$PORT"];
        manager = "web";
      };
    };
  };
}
